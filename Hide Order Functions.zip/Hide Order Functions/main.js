// Hide Order Functions

// 1-misol
// function getNames(arr) {
//   let newArr = arr.map((el, i, arr) => {
//     let grade;
//     if (el.percent >= 85 && el.percent < 100) {
//       grade = 5;
//     } else if (el.percent >= 70 && el.percent < 85) {
//       grade = 4;
//     } else if (el.percent >= 60 && el.percent < 70) {
//       grade = 3;
//     } else {
//       grade = 2;
//     }
//     return {
//       name: el.name,
//       percent: el.percent,
//       grade,
//     };
//   });
//   return newArr;
// }
// console.log(
//   getNames([
//     { name: "Quincy", percent: 96 },
//     { name: "Jason", percent: 84 },
//     { name: "Alexis", percent: 100 },
//     { name: "Sam", percent: 65 },
//     { name: "Katie", percent: 90 },
//     { name: "Anna", percent: 75 },
//   ])
// );

// Misol-2
let arr = ["dog", "chicken", "cat", "dog", "chicken", "chicken", "rabbit"];
function reduceAnimals() {
  arr.reduce();
}
